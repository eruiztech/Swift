//
//  APPViewController.h
//  Soccer Rush
//
//  Created by Edgar Ruiz on 6/20/14.
//  Copyright (c) 2014 Edgar Ruiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APPViewController : UIViewController
{
    
    
    IBOutlet UIImageView *AnimatedBackground;
    
}
@end
