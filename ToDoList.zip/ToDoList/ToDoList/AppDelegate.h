//
//  AppDelegate.h
//  ToDoList
//
//  Created by Edgar Ruiz on 9/3/15.
//  Copyright (c) 2015 Edgar Ruiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

