//
//  ViewController.swift
//  Calculator
//
//  Created by Edgar Ruiz on 10/7/15.
//  Copyright © 2015 Edgar Ruiz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Screen: UILabel!
    var firstNumber = Int()
    var secondNumber = Int()
    var isTypingNumber = false
    var result = Int()
    var operation = ""
    
    
    @IBAction func number(_ sender: AnyObject) {
        let number = sender.currentTitle
        if isTypingNumber == true{
            Screen.text = Screen.text! + number!!
        }
        else{
            Screen.text = number!;
        }
        isTypingNumber = true
    }
    
    @IBAction func operation(_ sender: AnyObject) {
        isTypingNumber = false
        firstNumber = Int(Screen.text!)!
        operation = sender.currentTitle!!
    }
    
    
    @IBAction func equals(_ sender: AnyObject) {
        secondNumber = Int(Screen.text!)!
        if operation == "+"{
            result = firstNumber + secondNumber
        }
        else if operation == "-"{
            result = firstNumber - secondNumber
        }
        else if operation == "x"{
            result = firstNumber * secondNumber
        }
        else{
            result = firstNumber / secondNumber
        }
        Screen.text = "\(result)"
    }
    
    
    @IBAction func clear(_ sender: AnyObject) {
        firstNumber = 0
        secondNumber = 0
        isTypingNumber = false
        result = 0
        Screen.text = "\(result)"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

